# Cohort Retention and Churn: A Survival Analysis

**Question:** *(fill in)* Which acquisition channel retains users best, where in the signup-to-repeat-purchase funnel does each channel lose people, and is the difference between channels statistically meaningful?

**Key findings:** *(fill in after running; 3-sentence summary of the channel comparison, retention numbers, and recommendation)*

**Tools:** R, dplyr/tidyr (cohort tables), `survival` + `survminer` (Kaplan-Meier, log-rank test, Cox regression), ggplot2, Quarto

## Why this project

Most beginner portfolios stop at "retention rate = X%." This project goes further in two ways that matter for real analyst work:

1. **Cohort structure.** Retention isn't one number — it's a curve that depends on how long a user has been around, and different signup cohorts can behave differently over time (e.g. if the product changed, or acquisition quality shifted).
2. **Proper handling of incomplete data.** A user who signed up last week hasn't had a chance to churn yet. Treating them as "retained" or throwing them out both bias the result. Survival analysis — the same statistical toolkit used in medical research for time-to-event data — handles this correctly through censoring.

## Reproduce

1. Get data: run `source("R/00_simulate_data.R")` for a ready-to-use simulated dataset with realistic cohort/channel structure (label results as illustrative if you keep this), **or** substitute real event-log data (see `R/00_get_data.R`).
2. `install.packages(c("tidyverse", "janitor", "survival", "survminer", "broom", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_cohort_analysis.R` (cohort table + funnel)
   - `R/03_survival_analysis.R` (Kaplan-Meier, log-rank test, Cox model)
   - Render `reports/report.qmd`

## Method in brief

1. **Define a cohort:** all users who signed up in the same calendar month.
2. **Build a retention table:** for each cohort and each "months since signup," what share of users who *could have been observed* that long were still active? (Recent cohorts are correctly excluded from periods they haven't reached yet — this is the detail most beginner cohort analyses get wrong.)
3. **Compare channels at fixed horizons** (e.g. 3-month, 6-month retention) — simple and intuitive, but a single snapshot.
4. **Go further with survival analysis:** treat "time until churn" as the outcome, with still-active users correctly marked as censored (not churned, not immortal — "survived at least this long"). Kaplan-Meier estimates the full retention curve non-parametrically; a log-rank test checks if channel curves differ more than chance would explain; a Cox model turns that into an interpretable hazard ratio.
5. **Map the funnel:** signup → activated → first purchase → repeat purchase, by channel, to find *where* each channel loses people, not just *whether* it retains well overall.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Cohort | A group of users who signed up in the same period, tracked together over time |
| Retention rate | Share of a cohort still active N periods after signup |
| Censoring | A user who hasn't churned yet isn't "retained forever" — they're "survived at least this long, outcome unknown" |
| Survival curve | The probability of still being active, as a function of time since signup |
| Kaplan-Meier estimator | A non-parametric way to estimate a survival curve directly from (possibly censored) time-to-event data |
| Log-rank test | Tests whether two or more survival curves differ more than chance would explain |
| Cox proportional hazards | A regression model for time-to-event data; coefficients come out as hazard ratios |
| Hazard ratio | How much more (or less) likely an event is to happen at any given moment, relative to a reference group |
| Funnel | The sequence of steps a user passes through (signup → activation → purchase); conversion rate at each step shows where people drop off |

## Project structure

```
R/00_get_data.R              real-data source notes
R/00_simulate_data.R         generates the default simulated dataset
R/cleaning.R                 cleaning function
R/01_clean.R                 run cleaning
R/cohort_functions.R         retention table + channel comparison functions
R/02_cohort_analysis.R       run cohort table, funnel summary
R/03_survival_analysis.R     Kaplan-Meier, log-rank test, Cox model
reports/report.qmd           full write-up: cohort heatmap, funnel, survival curves, recommendation
```

## Limitations

*(fill in)*
