# Reusable functions for classic cohort retention analysis.
# "Cohort" here = all users who signed up in the same calendar month.

library(dplyr)
library(tidyr)

#' Build a cohort retention table.
#'
#' For each signup cohort (month) and each number of months since signup,
#' what fraction of that cohort was still active?
#'
#' @param df Cleaned user data with signup_month, months_active, max_months_obs.
#' @param max_period Maximum months-since-signup to compute (cap long tails).
#' @return A tibble: cohort, period (months since signup), n_users (cohort size),
#'   n_active (users retained at that period), retention (n_active / n_users).
build_retention_table <- function(df, max_period = 11) {
  cohort_sizes <- df |>
    count(signup_month, name = "n_users")

  # For each user, they count as "active" at period p if months_active >= p
  # AND they were actually observable that far (max_months_obs >= p) --
  # this second condition is what keeps very recent cohorts from being
  # penalized for periods that simply haven't happened yet.
  expand_grid(
    df |> select(user_id, signup_month, months_active, max_months_obs),
    period = 0:max_period
  ) |>
    filter(max_months_obs >= period) |>     # only count periods we could have observed
    mutate(active = months_active >= period) |>
    group_by(signup_month, period) |>
    summarise(
      n_observable = n(),
      n_active     = sum(active),
      retention    = n_active / n_observable,
      .groups = "drop"
    ) |>
    left_join(cohort_sizes, by = "signup_month")
}

#' Summarize retention by channel at a fixed horizon (e.g. month 3).
#'
#' @param df Cleaned user data.
#' @param horizon Number of months since signup to evaluate at.
#' @return A tibble of channel, n_eligible, n_retained, retention_rate.
retention_by_channel <- function(df, horizon = 3) {
  df |>
    filter(max_months_obs >= horizon) |>   # only cohorts old enough to be evaluated at this horizon
    group_by(channel) |>
    summarise(
      n_eligible = n(),
      n_retained = sum(months_active >= horizon),
      retention_rate = n_retained / n_eligible,
      .groups = "drop"
    )
}
