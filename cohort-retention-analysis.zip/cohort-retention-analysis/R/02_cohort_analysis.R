library(dplyr)
source("R/cohort_functions.R")

df <- readRDS("data/clean/users_clean.rds")

retention_table <- build_retention_table(df)
saveRDS(retention_table, "data/clean/retention_table.rds")

channel_3mo <- retention_by_channel(df, horizon = 3)
channel_6mo <- retention_by_channel(df, horizon = 6)
print(channel_3mo)
print(channel_6mo)
saveRDS(list(m3 = channel_3mo, m6 = channel_6mo), "data/clean/retention_by_channel.rds")

# Funnel: signup -> activated -> first purchase -> repeat purchase, by channel
funnel_summary <- df |>
  group_by(channel) |>
  summarise(
    signups         = n(),
    activated       = sum(activated),
    first_purchase  = sum(first_purchase),
    repeat_purchase = sum(repeat_purchase),
    .groups = "drop"
  )
print(funnel_summary)
saveRDS(funnel_summary, "data/clean/funnel_summary.rds")
