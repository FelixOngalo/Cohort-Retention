# Simulate 12 months of signups and product usage for a subscription app,
# with realistic cohort structure: three acquisition channels with
# genuinely different retention behavior, so the analysis has something
# real to find. Numbers are illustrative, not real findings.

library(dplyr)
library(purrr)
library(lubridate)
library(readr)

set.seed(2026)

n_users       <- 6000
start_date    <- as_date("2025-01-01")
end_date      <- as_date("2025-12-01")   # last signup month
observation_end <- as_date("2026-02-28")  # "today" for this simulated dataset

channels <- c("organic", "paid_social", "referral")
channel_weights   <- c(0.45, 0.35, 0.20)
# Monthly retention probability by channel -- referral retains best,
# paid_social worst, which is a common real-world pattern worth
# demonstrating (cheap acquisition often churns faster).
channel_retention <- c(organic = 0.80, paid_social = 0.62, referral = 0.88)

signup_months <- seq(start_date, end_date, by = "month")

users <- tibble(
  user_id      = seq_len(n_users),
  channel      = sample(channels, n_users, replace = TRUE, prob = channel_weights),
  signup_date  = sample(signup_months, n_users, replace = TRUE) +
                 days(sample(0:27, n_users, replace = TRUE))
)

# For each user, simulate whether they're still active each month after
# signup using their channel's retention probability (geometric decay),
# capped at the observation window.
simulate_user_activity <- function(user_id, signup_date, channel) {
  p_retain <- channel_retention[[channel]]
  max_months <- interval(signup_date, observation_end) %/% months(1)
  if (max_months < 0) max_months <- 0

  active_months <- 0
  for (m in seq_len(max_months)) {
    if (runif(1) < p_retain) {
      active_months <- m
    } else {
      break   # churned -- stops being active from here on
    }
  }

  tibble(
    user_id        = user_id,
    months_active  = active_months,
    churned        = active_months < max_months,   # FALSE = still active/censored at observation_end
    max_months_obs = max_months
  )
}

activity <- pmap_dfr(
  list(users$user_id, users$signup_date, users$channel),
  simulate_user_activity
)

users <- users |> left_join(activity, by = "user_id")

# Build an event log: a login event for each active month, plus a
# purchase funnel (activation -> first purchase -> repeat purchase)
# with different conversion rates by channel.
activation_rate <- c(organic = 0.70, paid_social = 0.55, referral = 0.78)
purchase_rate   <- c(organic = 0.40, paid_social = 0.25, referral = 0.50)
repeat_rate     <- c(organic = 0.55, paid_social = 0.35, referral = 0.65)

funnel <- users |>
  rowwise() |>
  mutate(
    activated      = runif(1) < activation_rate[[channel]],
    first_purchase = activated && (runif(1) < purchase_rate[[channel]]),
    repeat_purchase = first_purchase && (runif(1) < repeat_rate[[channel]])
  ) |>
  ungroup()

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
write_csv(funnel, "data/raw/users.csv")
message("Simulated ", nrow(funnel), " users across ", length(channels), " channels.")
message("Observation window ends ", observation_end, " -- used for censoring in survival analysis.")
