# Cleaning for the users/funnel dataset.

library(dplyr)
library(janitor)
library(lubridate)

clean_users <- function(raw) {
  raw |>
    clean_names() |>
    mutate(
      signup_date  = as_date(signup_date),
      signup_month = floor_date(signup_date, "month"),
      channel      = factor(channel)
    ) |>
    filter(!is.na(signup_date))
}
