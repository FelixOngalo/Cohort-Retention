# Data for this project: user-level signup + event log data.
#
# OPTION A (real data): Kaggle "Relax Inc. Data Science Challenge" or any
#   SaaS/app event-log dataset with columns for user_id, event timestamp,
#   signup date, and acquisition channel. Place as data/raw/events.csv
#   and data/raw/users.csv (adjust R/01_clean.R column names to match).
#
# OPTION B (runs immediately, no download): simulated data with realistic
#   cohort structure -- different retention curves by acquisition channel,
#   and a funnel from signup through repeat purchase. This is what the
#   rest of the pipeline is built against by default.
#   Run R/00_simulate_data.R.
#
# Either way, label clearly in your README/report whether results are
# from real or simulated data -- do not present simulated numbers as
# real findings.

message("Use Option A (download real event data) or Option B (source('R/00_simulate_data.R')).")
