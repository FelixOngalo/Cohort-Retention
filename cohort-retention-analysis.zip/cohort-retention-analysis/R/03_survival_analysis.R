# Churn as a time-to-event (survival analysis) problem, not just a
# point-in-time retention rate. This answers a different question than
# the cohort table: not "what % are retained at month 3" but "what does
# the full churn curve look like, and does it differ by channel in a
# way that's statistically meaningful, accounting for users who haven't
# had a chance to churn yet (censoring)?"

library(survival)
library(dplyr)

df <- readRDS("data/clean/users_clean.rds")

# months_active   = how long the user was observed as active (the "time")
# churned (TRUE)  = the event (churn) was observed
# churned (FALSE) = user was still active when observation ended --
#                   "right-censored": we know they survived AT LEAST
#                   this long, but don't know their true total lifespan.
# Surv() encodes exactly this: time + event indicator.
surv_obj <- Surv(time = df$months_active, event = as.numeric(df$churned))

# Kaplan-Meier estimate: the standard non-parametric way to estimate a
# survival curve (here, "retention curve") from censored data, overall
# and split by channel.
km_overall <- survfit(surv_obj ~ 1, data = df)
km_channel <- survfit(surv_obj ~ channel, data = df)

# Log-rank test: is there a statistically significant difference between
# the channels' survival curves, or could the differences we see in the
# KM plot be due to chance?
logrank_test <- survdiff(surv_obj ~ channel, data = df)

# Cox proportional hazards model: like logistic regression but for
# time-to-event data. Gives a hazard ratio per channel -- "paid_social
# users churn at X times the rate of organic users at any given month,"
# which is a more precise statement than a single retention percentage.
cox_model <- coxph(surv_obj ~ channel, data = df)

print(km_channel)
print(logrank_test)
print(summary(cox_model))

saveRDS(list(
  km_overall   = km_overall,
  km_channel   = km_channel,
  logrank_test = logrank_test,
  cox_model    = cox_model
), "data/clean/survival_results.rds")
