library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/users.csv", show_col_types = FALSE)
clean <- clean_users(raw)

cat("Users:", nrow(clean), "\n")
cat("Channels:", paste(levels(clean$channel), collapse = ", "), "\n")
cat("Signup months:", as.character(min(clean$signup_month)), "to", as.character(max(clean$signup_month)), "\n")

saveRDS(clean, "data/clean/users_clean.rds")
